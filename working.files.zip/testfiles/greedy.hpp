#ifndef GREEDY_HPP
#define GREEDY_HPP
#include <vector>
#include "ticket.hpp"

float greedy_value_time(Scope_Ticket* arr, int size);

#endif