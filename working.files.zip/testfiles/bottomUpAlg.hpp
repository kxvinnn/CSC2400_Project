#ifndef BOTTOMUPALG_HPP
#define BOTTOMUPALG_HPP
#include "ticket.hpp"

float runBottomUpDP(Scope_Ticket *tickets, int size);

#endif