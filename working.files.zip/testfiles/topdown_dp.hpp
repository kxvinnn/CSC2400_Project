#ifndef TOPDOWN_DP_HPP
#define TOPDOWN_DP_HPP

#include "ticket.hpp"

float telescopeScheduleTopDown(Scope_Ticket arr[], int n);

#endif
