#ifndef BRUTE_FORCE_HPP
#define BRUTE_FORCE_HPP

#include "ticket.hpp"

long long bruteForceSchedule(Scope_Ticket* arr, int size);

#endif