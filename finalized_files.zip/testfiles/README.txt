To run this from the command line, go to the directory the
.cpp files are stored in. Then type in the following commands:

g++ *.cpp -o executable_name

Windows:
     Go to the directory the executable is stored in.
     Type in the command line:
     executable_name

Linux:
     Go to the directory the executable is stored in.
     Type in the command line:
     ./executable_name

To run the ticketMaker.cpp, go to the Code_Delivery directory
and type this into the command line:
	g++ ticketMaker.cpp -o executable_name
and to run this executable, follow the same instructions as above.
